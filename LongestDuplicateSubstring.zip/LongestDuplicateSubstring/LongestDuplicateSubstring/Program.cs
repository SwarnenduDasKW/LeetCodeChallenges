﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LongestDuplicateSubstring
{
    class Program
    {

        //public static List<string> allSubString = new List<string>();
        public static string longestDupSubStr = string.Empty;
        static void Main(string[] args)
        {

            string mainString = "banana";

            Console.WriteLine("This program will print all the combinations of contiguous substrings for a word {0}:-", mainString);

            DisplaySubstring(mainString, mainString.Length - 1);

            Console.WriteLine("Longest Duplicate Substring: {0}", longestDupSubStr);
            Console.ReadLine();
        }

        public static void DisplaySubstring(string mainString, int windowSize)
        {
            int i = 0;
            List<string> allSubString = new List<string>();
            string compareString = string.Empty;
            string tempS=string.Empty;

            if (windowSize < 2)
                return;

            while (i + windowSize <= mainString.Length)
            {
                tempS = mainString.Substring(i, windowSize);
                if (allSubString.IndexOf(tempS) >= 0)
                {
                    longestDupSubStr = tempS;
                    return;
                }
                allSubString.Add(tempS);

                Console.WriteLine("{0}",mainString.Substring(i,windowSize));

                i++;
            }
            windowSize = windowSize - 1;
            DisplaySubstring(mainString, windowSize);
        }
    }
}
