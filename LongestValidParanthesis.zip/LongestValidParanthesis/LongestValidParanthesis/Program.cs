﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LongestValidParanthesis
{
    class Program

    {
        static int count = 0;
        static int maxCount = 0;
        static void Main(string[] args)
        {

            string inputData = string.Empty;
            bool lbContinuePattern = false;
            Console.WriteLine("Enter a combination of open and closed brackets ( and )");
            //inputData = Console.ReadLine();
            inputData = "(()((((()()))())))()()(()()))()()()))";

            int maxSets = PatternPresent(inputData.Substring(0, 3), inputData.Substring(3), ref lbContinuePattern);
           
            Console.WriteLine("Longest valid paranthesis is {0}",maxSets);
            Console.ReadLine();
        }

        public static int PatternPresent(string partString, string originalData, ref bool lbMatchNextPattern)
        {
            bool matchfound = false;
            

            if (originalData.Length < 3)
                return maxCount;
            
            if((partString[0] == '(' && partString[1] == ')') || (partString[1] == '(' && partString[2] == ')'))
            {
                count++;
                matchfound = true;
            }

            if (matchfound)
            {
                if ((partString[2] == '(' && originalData[0] == ')')
                    || (partString[2] == ')' && originalData[0] == '(' && originalData[1] == ')'))
                {
                    lbMatchNextPattern = true;
                }
            }
            else
            {
                lbMatchNextPattern = false;
            }

            if (partString[2] == '(' && originalData[0] == ')')
                count++;

            if(count > maxCount)
                maxCount = count;

            if (!lbMatchNextPattern)
            {
                count = 0;
            }
           
            partString = originalData.Substring(0, 3);
            originalData = originalData.Substring(3);

            PatternPresent(partString, originalData, ref lbMatchNextPattern);

            return maxCount;
        }
    }
}
